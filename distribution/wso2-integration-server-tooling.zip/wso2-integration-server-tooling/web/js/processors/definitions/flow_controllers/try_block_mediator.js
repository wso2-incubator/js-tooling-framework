/**
 * Copyright (c) 2016, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
 *
 * WSO2 Inc. licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

var Processors = (function (processors) {

    var flowControllers = processors.flowControllers || {};

    //Define manipulator mediators
    var tryBlockMediator = {
        id: "TryBlockMediator",
        title: "Try Block",
        icon: "images/tool-icons/dgm-try-catch.svg",
        colour : "#ffffff",
        type : "ComplexProcessor",
        containableElements: [{container:"tryContainer",children:[{title:"Try"}]},{container:"catchContainer",children:[{title:"Catch"}]}],
        dragCursorOffset : { left: 24, top: -5 },
        createCloneCallback : function(view){
            function cloneCallBack() {
                var div = view.createContainerForDraggable();
                d3.xml("images/tool-icons/dgm-try-catch.svg").mimeType("image/svg+xml").get(function(error, xml) {
                    if (error) throw error;
                    var svg = xml.getElementsByTagName("svg")[0];
                    d3.select(svg).attr("width", "48px").attr("height", "108px");
                    div.node().appendChild(svg);
                });
                return div.node();
            }
            return cloneCallBack;
        },
        parameters: [
            {
                key: "exception",
                value: "Exception"
            },
            {
                key: "description",
                value: "Description"
            }
        ],
        propertyPaneSchema: [
            {
                key: "exception",
                text: "Exception"
            },
            {
                key: "description",
                text: "Description"
            }
        ],
        utils: {
            getMyPropertyPaneSchema : function () {
                return Processors.flowControllers.TryBlockMediator.propertyPaneSchema;
            },
            getMyParameters: function (model) {
                return model.attributes.parameters;
            },
            saveMyProperties: function (model, inputs) {
                model.attributes.parameters = [
                    {
                        key: "exception",
                        value: inputs.exception.value
                    },
                    {
                        key: "description",
                        value: inputs.description.value
                    }
                ];
            },
            canConnectTo: function () {
                return ['Worker', 'EndPoint'];
            },
            getMySubTree: function (model) {
                // Generate Subtree for the try block
                var tryBlock = model.get('containableProcessorElements').models[0];
                var tryBlockNode = new TreeNode("TryBlock", "TryBlock", "try{", "}");
                for (var itr = 0; itr < tryBlock.get('children').models.length; itr++) {
                    var child = tryBlock.get('children').models[itr];

                    if (child instanceof SequenceD.Models.MessagePoint && child.get('direction') == 'outbound') {
                        var endpoint = child.get('message').get('destination').get('parent').attributes.parameters[0].value;
                        var uri = child.get('message').get('destination').attributes.parameters[1].value;
                        // When we define the properties, need to extract the endpoint from the property
                        definedConstants["HTTPEP"] = {name: endpoint, value: uri};
                        var l = new TreeNode("InvokeMediator", "InvokeMediator", ("response = invoke(endpointKey=" +
                        endpoint + ", messageKey=m)"), ";");
                        tryBlockNode.getChildren().push(l);
                    } else {
                        tryBlockNode.getChildren().push(child.get('utils').getMySubTree(child));
                    }
                }

                // Generate the Subtree for the catch block
                var catchBlock = model.get('containableProcessorElements').models[1];
                var catchBlockNode = new TreeNode("CatchBlock", "CatchBlock", "catch(Exception e){", "}");
                for (var itr = 0; itr < catchBlock.get('children').models.length; itr++) {
                    var child = catchBlock.get('children').models[itr];

                    if (child instanceof SequenceD.Models.MessagePoint && child.get('direction') == 'outbound') {
                        var endpoint = child.get('message').get('destination').get('parent').attributes.parameters[0].value;
                        var uri = child.get('message').get('destination').get('parent').attributes.parameters[1].value;
                        // When we define the properties, need to extract the endpoint from the property
                        definedConstants["HTTPEP"] = {name: endpoint, value: uri};
                        var l = new TreeNode("InvokeMediator", "InvokeMediator", ("response = invoke(endpointKey=" +
                        endpoint + ", messageKey=m)"), ";");
                        catchBlockNode.getChildren().push(l);
                    } else {
                        catchBlockNode.getChildren().push(child.get('utils').getMySubTree(child));
                    }
                }
                var tryCatchNode = new TreeNode("TryCatchMediator", "TryCatchMediator", "", "");
                tryCatchNode.getChildren().push(tryBlockNode);
                tryCatchNode.getChildren().push(catchBlockNode);

                return tryCatchNode;

            },
            createMyModel: function (model, parameters) {
                var position = new GeoCore.Models.Point({
                    x: 0,
                    y: 0
                });
                var processor = model.createProcessor(
                    Processors.flowControllers.TryBlockMediator.title,
                    position,
                    Processors.flowControllers.TryBlockMediator.id,
                    {
                        type: Processors.flowControllers.TryBlockMediator.type,
                        initMethod: Processors.flowControllers.TryBlockMediator.init
                    },
                    {colour: Processors.flowControllers.TryBlockMediator.colour},
                    parameters,
                    Processors.flowControllers.TryBlockMediator.utils
                );
                model.addChild(processor);
                return processor;
                
            },
            createMyContainableProcessorElement: function (processor, title) {
                var containableProcessorElem = new SequenceD.Models.ContainableProcessorElement(lifeLineOptions);
                containableProcessorElem.type = 'ContainableProcessorElement';
                containableProcessorElem.set('title', title);
                containableProcessorElem.set('utils', Processors.flowControllers.TryBlockMediator.utils);
                containableProcessorElem.parent(processor);
                processor.containableProcessorElements().add(containableProcessorElem);
                return containableProcessorElem;
                
            }
        }
    };

    // Add defined mediators to manipulators
    // Mediator id should be exactly match to name defining here.(Eg : "LogMediator")
    flowControllers.TryBlockMediator = tryBlockMediator;

    processors.flowControllers = flowControllers;

    return processors;

}(Processors || {}));
